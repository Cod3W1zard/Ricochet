from unittest import case

import pygame
import player
import enemy
walls = None
plr = None
PLAYER_WIDTH = 16
PLAYER_HEIGHT = 16
enemies = None

class TaggedRect(pygame.Rect):
    def __init__(self, x, y, width, height, sprite = None, tag="", flip_x = False, flip_y = False):
        super().__init__(x, y, width, height)
        self.tag = tag
        self.sprite = sprite
        if self.sprite != None:
            self.sprite = pygame.image.load(f"Assets/Images/{self.sprite}.png").convert_alpha()
            self.sprite = pygame.transform.flip(self.sprite, flip_x, flip_y)
            self.sprite = pygame.transform.scale(self.sprite, (50, 50))

def Generate(screen):
    plr = player.Player(screen, (150,200), PLAYER_WIDTH, PLAYER_HEIGHT, "play")
    enemies = [
        enemy.Enemy(screen, (450,200), PLAYER_WIDTH, PLAYER_HEIGHT, plr),
        enemy.Enemy(screen, (350,350), PLAYER_WIDTH, PLAYER_HEIGHT, plr),
        enemy.Enemy(screen, (450,100), PLAYER_WIDTH, PLAYER_HEIGHT, plr),
        enemy.Enemy(screen, (350,150), PLAYER_WIDTH, PLAYER_HEIGHT, plr)
        ]
    walls = [
        TaggedRect(50, 50, 50, 50, sprite = "Scenery/plantpot_crnr_upsidedown", flip_x = True),
        TaggedRect(50, 100, 50, 50, sprite = "Scenery/plantpot_top_upsidedown", flip_x = True),
        TaggedRect(100, 50, 50, 50, sprite = "Scenery/plantpot_side_upsidedown", flip_x = True),
        TaggedRect(50, 250, 50, 50, sprite = "Scenery/plantpot_top"),
        TaggedRect(50, 300, 50, 50, sprite = "Scenery/plantpot_crnr"),
        TaggedRect(100, 300, 50, 50, sprite = "Scenery/plantpot_side"),
        TaggedRect(450, 50, 50, 50, sprite = "Scenery/plantpot_side_upsidedown"),
        TaggedRect(500, 100, 50, 50, sprite = "Scenery/plantpot_top_upsidedown"),
        TaggedRect(500, 50, 50, 50, sprite = "Scenery/plantpot_crnr_upsidedown"),
        TaggedRect(500, 250, 50, 50, sprite = "Scenery/plantpot_top", flip_x = True),
        TaggedRect(500, 300, 50, 50, sprite = "Scenery/plantpot_crnr", flip_x = True),
        TaggedRect(450, 300, 50, 50, sprite = "Scenery/plantpot_side", flip_x = True),
        TaggedRect(250, 150, 50, 50, sprite = "Scenery/plantpot_crnr_upsidedown", flip_x = True),
        TaggedRect(300, 150, 50, 50, sprite = "Scenery/plantpot_crnr_upsidedown"),
        TaggedRect(250, 200, 50, 50, sprite = "Scenery/plantpot_crnr"),
        TaggedRect(300, 200, 50, 50, sprite = "Scenery/plantpot_crnr", flip_x = True),
        TaggedRect(275, 0, 50, 50, sprite = "Scenery/shed", tag = "shed"),
        TaggedRect(0, 0, 1, 400, tag = "wall"),
        TaggedRect(0, 0, 600, 1, tag = "wall"),
        TaggedRect(599, 0, 1, 400, tag = "wall"),
        TaggedRect(0, 399, 600, 1, tag = "wall")
        ]
    return (plr, enemies, walls)