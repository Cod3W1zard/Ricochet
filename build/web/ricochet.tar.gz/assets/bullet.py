import pygame

pbullets = []
ebullets = []

class Bullet:
       p = pygame.Vector2(0, 0)
       v = pygame.Vector2(0, 0)
       r = 1
       maxbounces = 5
       curbounces = 0
       daM = 4       
       baseDamage = 1
       speed = 5

       def __init__(self, surface, center, radius, speed, direction, type = "player"):
              self.surface = surface
              self.p = pygame.Vector2(center)
              self.r = radius
              self.v = pygame.Vector2(direction * speed)
              self.hitbox = pygame.Rect(0, 0, radius*2.5, radius*2.5)
              self.hitbox.center = self.p
              self.curbounces = 0
              self.type = type
              self.image = pygame.image.load("Assets/Images/shard.png").convert_alpha()

       def move(self, rects):

              c = False

              self.p.x += self.v.x
              self.hitbox.center = self.p
              
              for rect in rects:
                     if self.hitbox.colliderect(rect):
                            self.v.x = -self.v.x
                            self.p.x += self.v.x
                            self.hitbox.center = self.p
                            c = True
                            break
              
              self.p.y += self.v.y
              self.hitbox.center = self.p

              for rect in rects:
                     if self.hitbox.colliderect(rect):
                            self.v.y = -self.v.y
                            self.p.y += self.v.y
                            self.hitbox.center = self.p
                            c = True
                            break
              self.hitbox.center = self.p
              if c:
                     self.curbounces += 1
       
       def hit(self):
              if self.type == "player":
                     return self.daM * self.curbounces
              else:
                     return self.baseDamage
       
       def draw(self):
              if self.type == "player":
                     if self.curbounces == 0:
                            color = (255, 0, 0)
                     else:
                            color = (255, 255, 255)
              else: 
                     color = (255, 255, 0)
              tinted_image = self.image.copy()
              tinted_image.fill(color, special_flags=pygame.BLEND_RGBA_MULT)
              self.surface.blit(tinted_image, self.hitbox)